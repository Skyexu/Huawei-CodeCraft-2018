package com.elasticcloudservice.predict;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
//                            _ooOoo_
//                           o8888888o
//                           88" . "88
//                           (| -_- |)
//                            O\ = /O
//                        ____/`---'\____
//                      .   ' \\| |// `.
//                       / \\||| : |||// \
//                     / _||||| -:- |||||- \
//                       | | \\\ - /// | |
//                     | \_| ''\---/'' | |
//                      \ .-\__ `-` ___/-. /
//                   ___`. .' /--.--\ `. . __
//                ."" '< `.___\_<|>_/___.' >'"".
//               | | : `- \`.;`\ _ /`;.`/ - ` : | |
//                 \ \ `-. \_ __\ /__ _/ .-` / /
//         ======`-.____`-.___\_____/___.-`____.-'======
//                            `=---='
//
//         .............................................
//                  佛祖保佑             永无BUG
public class Predict {

    public static int trainData[][] = new int[10000][100];
    public static  LocalDateTime trainStartDateTime;
    public static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static int[][] flavorInfo = {{0,0},{1,1024},{1,2048},{1,4096},{2,2048},{2,4096},{2,8192},{4,4096},{4,8192},{4,16384},{8,8192},{8,16384},
            {8,32768},{16,16384},{16,32768},{16,65536}};


    /**
     * 
     * @param ecsContent
     * @param inputContent
     * @return
     * @// TODO: 2018/3/12 限定预测的 flavor  减少时间开销 
     */
	public static String[] predictVm(String[] ecsContent, String[] inputContent) {

		/** =========do your work here========== **/

		String[] results = new String[ecsContent.length];
        int flavorNum; // 虚拟机个数
        int[] physicInfo = new int[3]; // 物理服务器CPU核数 内存大小（GB） 硬盘大小（GB）
        List<Integer> preFlavorList = new ArrayList<>();   // 虚拟机类型
        String keyword;    // 需要优化的资源维度名称（CPU或内存）
        int preStartTime; //预测开始时间索引
        int preEndTime; //预测开始时间索引
        int preDay ;   // 需要预测的天数

		List<String> history = new ArrayList<String>();
        // 解析训练文件
		for (int i = 0; i < ecsContent.length; i++) {
			if (ecsContent[i].contains("\t")
					&& ecsContent[i].split("\t").length == 3) {

				String[] array = ecsContent[i].split("\t");
				String uuid = array[0];
				String flavorName = array[1];
				String createTime = array[2];
                if (i == 0){
                    trainStartDateTime = LocalDateTime.parse(createTime,dateTimeFormatter);
                }
                int timeIndex = getTimeIndex(createTime,0);

                int flavor = Integer.parseInt(flavorName.substring(6));
                // 只需预测 15 种虚拟机
                if (flavor < 16){
                    trainData[timeIndex][flavor]++;
                }
				//history.add(uuid + " " + flavorName + " " + createTime);
			}
		}

		// 解析 input 文件
        String[] physicInfoString = inputContent[0].split(" ");
        physicInfo[0] = Integer.parseInt(physicInfoString[0]);  //CPU
        physicInfo[1] = Integer.parseInt(physicInfoString[1] ); //Memory
        physicInfo[2] = Integer.parseInt(physicInfoString[2]);  //硬盘
        flavorNum = Integer.parseInt(inputContent[2]);

        for (int i = 3; i < 3 + flavorNum; i++) {
            String[] flavorString = inputContent[i].split(" ");
            preFlavorList.add(Integer.parseInt(flavorString[0].substring(6)));
        }

        keyword = inputContent[3 + flavorNum + 1];

        String preStartString = inputContent[3 + flavorNum + 3];
        String preEndString = inputContent[3 + flavorNum + 4];
        System.out.println("preStartString: "+preStartString);
        System.out.println("trainStartTime: " + trainStartDateTime);

        preStartTime = getTimeIndex(preStartString,0);
        preEndTime = getTimeIndex(preEndString,0);

        System.out.println("preStartTime: " + preStartTime);
        preDay = preEndTime - preStartTime;
        Map<Integer,Integer> flavorResultMap1 = predictModel(preStartTime,preDay,preFlavorList);
        Map<Integer,Integer> flavorResultMap2 = predictModelPeriodRule(preStartTime,preDay,preFlavorList);
        //Map<Integer,Integer> flavorResultMap3  = predictModelConstantRegressionTwo(preStartTime,preDay,preFlavorList);
        Map<Integer,Integer> flavorResultMap4 = predictModelConstantRegressionOne(preStartTime,preDay,preFlavorList);
        Map<Integer,Integer> flavorResultMap5 = predictModelLinear(preStartTime,preDay,preFlavorList);
        // 加权
        Map<Integer,Integer> flavorResultMap = new HashMap<>();
        for (int flavorNumber : preFlavorList){
            //double preNumber = flavorResultMap1.get(flavorNumber) * 0.1 + flavorResultMap2.get(flavorNumber) * 0.3 + flavorResultMap4.get(flavorNumber) * 0.7;
            //double preNumber = flavorResultMap1.get(flavorNumber) * 0.5 + flavorResultMap4.get(flavorNumber) * 0.5;
            //double preNumber = flavorResultMap1.get(flavorNumber) * 0.3 + flavorResultMap4.get(flavorNumber) * 0.7;  // 90.021
            //double preNumber = flavorResultMap1.get(flavorNumber);
            //double preNumber = flavorResultMap2.get(flavorNumber) * 0.2 + flavorResultMap4.get(flavorNumber) * 0.8;
            double preNumber =flavorResultMap5.get(flavorNumber);
            //double preNumber = flavorResultMap5.get(flavorNumber) * 0.0 + flavorResultMap4.get(flavorNumber) * 1.0;
            flavorResultMap.put(flavorNumber,(int)Math.floor(preNumber));
        }
        //flavorResultMap = flavorResultMap4;

        List<Integer> cpu = new ArrayList<>();
        List<Integer> memory = new ArrayList<>();
        List<String> name = new ArrayList<>();
        // 初始
        cpu.add(0);
        memory.add(0);
        name.add("null");

       // int flavorTotal = 0; //预测的虚拟机总数
      //  List<String> flavorTypeNum = new ArrayList<>(); // 虚拟机规格名称1 虚拟机个数
        for (Map.Entry<Integer,Integer> map: flavorResultMap.entrySet()){
            int fNumber = map.getKey();
            int fTotal = map.getValue();
            for (int i = 0; i < fTotal; i++) {
                if (fTotal > 0){
                    name.add("flavor" + fNumber );
                    cpu.add(flavorInfo[fNumber][0]);
                    memory.add(flavorInfo[fNumber][1]/1024);
                }

            }
          //  flavorTotal += fTotal;
          //  flavorTypeNum.add("flavor"+ fNumber+ " " + fTotal);
        }
        /*
        // 分配虚拟机
        List<String> assignmentResult = Assignment2.startAssignment(keyword,physicInfo[0],physicInfo[1],cpu,memory,name);
        Map<String,Integer> flavorMap = new HashMap<>();

        // 以分配结果作为最后的虚拟机数量结果
        for (int i = 0; i < assignmentResult.size() ; i++) {
            String[] assignStr = assignmentResult.get(i).split(" ");
            for (int j = 1; j < assignStr.length; j = j+2) {
                if (flavorMap.containsKey(assignStr[j])){
                    flavorMap.put(assignStr[j],flavorMap.get(assignStr[j]) + Integer.parseInt(assignStr[j+1]));
                }else {
                    flavorMap.put(assignStr[j],Integer.parseInt(assignStr[j+1]));
                }
            }
        }

        int flavorTotal2 = 0; //预测的虚拟机总数
        List<String> flavorTypeNum2 = new ArrayList<>(); // 虚拟机规格名称1 虚拟机个数
        for (int flavor: preFlavorList){
            String flavorStr = "flavor" + flavor;
            if (flavorMap.containsKey(flavorStr)){
                flavorTypeNum2.add(flavorStr +" " +flavorMap.get(flavorStr));
                flavorTotal2 += flavorMap.get(flavorStr);
            }else {
                flavorTypeNum2.add(flavorStr + " " +0);
            }

        }
        */
        // 分配
        //List<Map<String,Integer>> assignmentResult = Assignment.startAssignment(keyword,physicInfo[0],physicInfo[1],cpu,memory,name);
        List<Map<String,Integer>> assignmentResult = Assignment3.startAssignment(keyword,physicInfo[0],physicInfo[1],cpu,memory,name,preFlavorList);
        Map<String,Integer> flavorMap = new HashMap<>();
        List<String> physicResult = new ArrayList<>();
        for (int i = 0; i < assignmentResult.size() ; i++) {
            Map<String,Integer> tempMap = assignmentResult.get(i);
            StringBuilder stringBuilder  = new StringBuilder();
            stringBuilder.append(i+1 +" ");
            for (Map.Entry<String,Integer> entry:
                 tempMap.entrySet()) {
                stringBuilder.append(entry.getKey()+" "+entry.getValue()+" ");
                if (flavorMap.containsKey(entry.getKey())){
                    flavorMap.put(entry.getKey(),flavorMap.get(entry.getKey()) + entry.getValue());
                }else {
                    flavorMap.put(entry.getKey(),entry.getValue());
                }
            }
            physicResult.add(stringBuilder.toString());
        }



        // 以分配结果作为最后的虚拟机数量结果
        int flavorTotal = 0; //预测的虚拟机总数
        List<String> flavorTypeNum = new ArrayList<>(); // 虚拟机规格名称1 虚拟机个数
        for (int flavor: preFlavorList){
            String flavorStr = "flavor" + flavor;
            if (flavorMap.containsKey(flavorStr)){
                flavorTypeNum.add(flavorStr +" " +flavorMap.get(flavorStr));
                flavorTotal += flavorMap.get(flavorStr);
            }else {
                flavorTypeNum.add(flavorStr + " " +0);
            }

        }

//        if (assignmentResult.isEmpty()){
//            assignmentResult.add("0");
//        }
        history.add(flavorTotal+"");
        history.addAll(flavorTypeNum);
        history.add(System.getProperty("line.separator"));
        history.add(assignmentResult.size()+"");
        history.addAll(physicResult);

		for (int i = 0; i < history.size(); i++) {
			results[i] = history.get(i);
            System.out.println(results[i]);
        }

		return results;
	}

    /**
     *  获取时间索引，从 0 开始
     *
     * @param timeString 时间字符串
     * @param timeType  时间类型 0 为天，1 为小时
     * @return 时间的索引，从 0 开始
     * @TODO: 2018/3/12 暂时只实现时间类型为天的
     */
	public static int getTimeIndex(String timeString,int timeType){

        LocalDateTime localDateTime = LocalDateTime.parse(timeString,dateTimeFormatter);
        LocalDate localDate1 = LocalDate.from(trainStartDateTime);
        LocalDate localDate2 = LocalDate.from(localDateTime);

        long daysDiff = ChronoUnit.DAYS.between(localDate1,localDate2);

        return (int)daysDiff;
    }

    /**
     *
     * @param preStartTime 预测的开始时间
     * @param preDay 需要预测的天数
     * @return
     * @// TODO: 2018/3/12 现在直接使用前预测天数的数据量，后面加入预测模型,先实现常数回归，再实现高级模型
     *
     */
    public static Map<Integer,Integer> predictModel(int preStartTime,int preDay,List<Integer> preFlavorList){
        Map<Integer,Integer> returnMap = new HashMap<>();
        int[] flavor = new int[100];
        int dayPeriod = 1;

        //System.out.println(preDay);
        for (int i = preDay * dayPeriod; i > 0; i-- ){
            for (Integer preFlavor : preFlavorList) {
                flavor[preFlavor] += trainData[preStartTime - i][preFlavor];
            }

        }
        for (Integer preFlavor : preFlavorList){
            flavor[preFlavor] = (int)Math.rint( flavor[preFlavor] * 1.0 /(preDay * dayPeriod) * preDay);
            returnMap.put(preFlavor,flavor[preFlavor]);
            //System.out.println("flavor"+preFlavor +" : "+ flavor[preFlavor]);
        }
        return returnMap;
    }

    /**
     *   线性人工权重
     * @param preStartTime 预测的开始时间
     * @param preDay 需要预测的天数
     * @return
     *
     *
     */
    public static Map<Integer,Integer> predictModelLinear(int preStartTime,int preDay,List<Integer> preFlavorList){
        Map<Integer,Integer> returnMap = new HashMap<>();
        //int period = (preStartTime -1) / preDay ;
        int period = 4 ;
        int[] flavor = new int[100];
        int dayPeriod = 1;
        int flavorSize = preFlavorList.size();
        double[][] trainMatrixOne = new double[flavorSize][period];  // 历史每 K 天的总虚拟机数

        for (int i = 0; i < flavorSize; i++) {
            // 存储每个 flavor 信息
            for (int j = 0; j < period; j++) {
                double total = 0;
                for (int k = 0; k < preDay; k++) {
                    total += trainData[preStartTime - (j + 1) * preDay + k][preFlavorList.get(i)];
                }
                trainMatrixOne[i][j] = total;
                System.out.println("flavor:" + i +"  period:" + j);
                System.out.println("trainMatrixOne: " + trainMatrixOne[i][j]);

            }
        }

        for (int i = 0; i < flavorSize; i++) {
            double number = 0;

            number = trainMatrixOne[i][0] * 0.55 + trainMatrixOne[i][1] * 0.3 +  trainMatrixOne[i][2] * 0.26 + trainMatrixOne[i][3] * 0.26;

            returnMap.put(preFlavorList.get(i),(int)Math.floor(number));
        }
        return returnMap;
    }

    public static double lossFuction(double y, double[] train,double distance) {
        double loss = 0;
        double numerator = 0; // 分子
        double denominator = 0; // 分母
        double denominatorLeft = 0;
        double denominatorRight = 0;
        if (distance > 1) {
            // 以周期形式
            for (int i = 0; i < train.length; i++) {
                loss += (y - train[i]) / (y + train[i]) * (1.0 / ((i + 1) * distance));
            }
        } else {
            // 以每日形式
            for (int i = 0; i < train.length; i++) {
                loss += (y - train[i]) / (y + train[i]) * (1.0 / (train.length - i));
            }
        }
        return Math.abs(loss);
    }

    public static double lossFuction2(double y, double[] train,double distance){
        double loss = 0;
        double weight;
        if (distance > 1){
            // 以周期形式
            for (int i = 0; i < train.length; i++) {
                weight = 1.0 / ((i+1)*distance);
                loss += (y - train[i])/(y + train[i]) * weight;
            }
        }else {
            // 以每日形式
            for (int i = 0; i < train.length; i++) {
                weight = 1.0 /(train.length - i );
                loss += (y - train[i])/(y + train[i]) * weight;
            }
        }
        return Math.abs(loss);
    }

    public static double getMin(double[] array){
        double minValue = array[0];
        for (int i = 0; i<array.length;i++){
            if (array[i]<minValue)
                minValue = array[i];
        }
        return minValue;

    }
    public static double getMax(double[] array){
        double maxValue = array[0];
        for (int i = 0; i<array.length;i++){
            if (array[i]>maxValue)
                maxValue = array[i];
        }
        return maxValue;

    }
    /**
     *  常数回归模型
     *
     *  样本，设预测天数为 K ，
     *  1. 历史每 K 天的总虚拟机数
     *  2. 历史每天虚拟机数 * K    ##
     *  3. 历史每两天虚拟机数 * K/2
     *
     * @param preStartTime
     * @param preDay
     * @param preFlavorList
     * @return
     */
    public static Map<Integer,Integer> predictModelConstantRegressionTwo(int preStartTime,int preDay,List<Integer> preFlavorList){
        Map<Integer,Integer> returnMap = new HashMap<>();
        int period = (preStartTime -1) / preDay ;
        int[] flavor = new int[100];
        int dayPeriod = 1;
        int flavorSize = preFlavorList.size();
        double[][] trainMatrixTwo = new double[flavorSize][preStartTime];  // 每个虚拟机型号每天的数量 * preDay

        //System.out.println(preDay);
        for (int i = 0; i < preStartTime; i++ ){
            for (int j = 0; j < flavorSize; j++) {
                //System.out.println(i+" "+ j + " " + trainData[i][preFlavorList.get(j)]);
                trainMatrixTwo[j][i] = trainData[i][preFlavorList.get(j)] * preDay * 1.0 ;
                //System.out.println(trainMatrixTwo[j][i]);
            }
        }
        for (int i = 0; i < flavorSize; i++) {
            List<Double> lossList = new ArrayList<>();
            List valueList = Arrays.asList(trainMatrixTwo[i]);
            int min = (int)getMin(trainMatrixTwo[i]);
            int max = (int)getMax(trainMatrixTwo[i]);
            System.out.println(min +" "+ max);
            for (int j = min; j <= max; j++) {
                lossList.add(lossFuction(j,trainMatrixTwo[i],1));
            }
            double value = Collections.min(lossList);
            System.out.println(value);
            returnMap.put(preFlavorList.get(i),lossList.indexOf(value) + min);
        }
        return returnMap;
    }
    /**
     *  常数回归模型 One
     *
     *  样本，设预测天数为 K ，
     *  1. 历史每 K 天的总虚拟机数   ##
     *  2. 历史每天虚拟机数 * K
     *  3. 历史每两天虚拟机数 * K/2
     *
     * @param preStartTime
     * @param preDay
     * @param preFlavorList
     * @return
     */
    public static Map<Integer,Integer> predictModelConstantRegressionOne(int preStartTime,int preDay,List<Integer> preFlavorList){
        Map<Integer,Integer> returnMap = new HashMap<>();
        //int period = (preStartTime -1) / preDay ;
        int period = 2 ;
        int[] flavor = new int[100];
        int dayPeriod = 1;
        int flavorSize = preFlavorList.size();
        double[][] trainMatrixOne = new double[flavorSize][period];  // 历史每 K 天的总虚拟机数

        for (int i = 0; i < flavorSize; i++) {
            // 存储每个 flavor 信息
            for (int j = 0; j < period; j++) {
                double total = 0;
                for (int k = 0; k < preDay; k++) {
                    total += trainData[preStartTime - (j + 1) * preDay + k][preFlavorList.get(i)];
                }
                trainMatrixOne[i][j] = total;
                System.out.println("flavor:" + i +"  period:" + j);
                System.out.println("trainMatrixOne: " + trainMatrixOne[i][j]);

            }
        }

        for (int i = 0; i < flavorSize; i++) {
            List<Double> lossList = new ArrayList<>();
            int min = (int)getMin(trainMatrixOne[i]);
            int max = (int)getMax(trainMatrixOne[i]);
            System.out.println(min +" "+ max);
            for (int j = min; j <= max; j++) {
                lossList.add(lossFuction(j,trainMatrixOne[i],preDay));
            }
            double value = Collections.min(lossList);
            System.out.println(value);
            returnMap.put(preFlavorList.get(i),lossList.indexOf(value) + min);
        }
        return returnMap;
    }
    /**
     * 周期因子规则
     * @param preStartTime
     * @param preDay
     * @param preFlavorList
     * 数据太稀疏，周期不敏感，结果不好
     * @return
     */
    public static Map<Integer,Integer> predictModelPeriodRule(int preStartTime,int preDay,List<Integer> preFlavorList){
        Map<Integer,Integer> returnMap = new HashMap<>();
        //int period = (preStartTime -1) / preDay ;    //平移周期
        int period = 2 ;
        int flavorSize = preFlavorList.size();
        // 转换训练矩阵为周期矩阵
        double[][][] periodMatrix = new double[flavorSize][period][preDay];
        double[][][] periodFactorMatrix = new double[flavorSize][period][preDay]; // periodMatrix 除以 周期均值
        double[][] periodFactor = new double[flavorSize][preDay];    // 每个虚拟机的周因子
        double[][] periodMean = new double[flavorSize][period];  // 每个虚拟机的周期均值
        int[][] predictDayValue = new int[flavorSize][preDay];  // 最后一周预测值
        double[] flavorBase = new double[flavorSize];
        int baseDay = preDay;
        for (int i = 0; i < flavorSize; i++) {
            // 存储每个 flavor 信息
            for (int j = 0; j < period; j++) {
                double total = 0;
                for (int k = 0; k < preDay; k++) {
                    periodMatrix[i][j][k]= trainData[preStartTime - preDay * (j + 1) + k][preFlavorList.get(i)] * 1.0;
                    total += periodMatrix[i][j][k];
                    if (j == period-1 && k> period-baseDay)
                        flavorBase[i] += periodMatrix[i][j][k];
                }
                System.out.println("flavor:" + i +"  period:" + j);
                System.out.println("total: " + total);

                periodMean[i][j] = total / preDay;
                System.out.println("periodMean: " + periodMean[i][j]);
                // 存储周期因子矩阵
                for (int k = 0; k < preDay; k++) {
                    if (periodMean[i][j] == 0)
                        periodFactorMatrix[i][j][k] = 0;
                    else
                        periodFactorMatrix[i][j][k] = periodMatrix[i][j][k] / periodMean[i][j];

                }
            }
            flavorBase[i] = flavorBase[i]/baseDay;
        }
        // 遍历周期因子矩阵 计算每个虚拟机的周因子 * base 最后一周平均
        for (int i = 0; i < flavorSize; i++) {
            int flavorNum = 0;
            for (int j = 0; j < preDay; j++) {
                List<Double> factorArr = new ArrayList<>();
                for (int k = 0; k < period; k++) {
                      factorArr.add(periodFactorMatrix[i][k][j]);
                }
                Collections.sort(factorArr);
                //中位数
                double mid = 0;
                int len = factorArr.size();
                if(len%2==0)
                    mid = (factorArr.get((len-1)/2)+factorArr.get(len/2))/2;
                else
                    mid = factorArr.get(len/2);
                periodFactor[i][j] = mid;
                double sum = 0;
                for (double d : factorArr) {
                    sum +=d;
                }
                double average = sum / factorArr.size();

                System.out.println("factor: "+i+" average: "+ average+ " mid: " + mid);
               // predictDayValue[i][j] = (int)Math.floor(average * periodMean[i][period-1]);  // 每天的周因子乘以最后一周的周平均
                predictDayValue[i][j] = (int)Math.floor(average * flavorBase[i]);
                flavorNum += predictDayValue[i][j];
            }
            returnMap.put(preFlavorList.get(i),flavorNum);
        }

        return returnMap;
    }
}
